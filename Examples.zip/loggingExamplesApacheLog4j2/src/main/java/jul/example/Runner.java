package jul.example;

import jul.example.anotherPackage.Inner;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/** https://logging.apache.org/log4j/2.x/maven-artifacts.html
 * https://logging.apache.org/log4j/2.x/manual/configuration.html
* */
public class Runner {

    private static final Logger logger = LogManager.getLogger(Runner.class);

    public static void main(String... args){
        Inner i=new Inner();
        logger.info("Мы начали");
        i.doSomeStuff(5);
        i.dummyWork();
        logger.info("Мы кончили");
    }

}
