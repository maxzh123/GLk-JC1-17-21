package jul.example.anotherPackage;


import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class Inner {
    private static final Logger logger = LogManager.getLogger(Inner.class);
    public void doSomeStuff(int arg){
        logger.log(Level.INFO,"Делает какую-то фигню: {}",arg);
        try{int i=arg/0;}
        catch(Exception e){
            logger.log(Level.ERROR,"Фигня не получилась:",e);
        }

    }
    public void dummyWork(){
        logger.debug("Дурная работа");
    }
}
