package jul.example.anotherPackage;

import java.util.logging.Level;
import java.util.logging.Logger;

public class Inner {
    public static final Logger logger = Logger.getLogger(Inner.class.getName());
    public void doSomeStuff(int arg){
        logger.log(Level.INFO,"Делает какую-то фигню:"+arg);
        try{int i=arg/0;}
        catch(Exception e){
            logger.log(Level.SEVERE,"Фигня не получилась:",e);
        }

    }
    public void dummyWork(){
        logger.log(Level.FINER,"Дурная работа");
    }
}
