package jul.example;

import jul.example.anotherPackage.Inner;

import java.util.logging.Logger;
/*
*   SEVERE (ошибка)
    WARNING (предупреждение)
    INFO (информационное сообщение)
    CONFIG
    FINE (сообщение об успешной операции)
    FINER
    FINEST
* */
public class Runner {

    static {
        // Обязательно до создания первого логера
        if (System.getProperty("java.util.logging.config.file")==null){
            System.setProperty("java.util.logging.config.file", "logging.properties");
        }
    }
    public static final Logger logger = Logger.getLogger(Runner.class.getName());
    public static void main(String... args){
        Inner i=new Inner();
        logger.info("Мы начали");
        i.doSomeStuff(5);
        i.dummyWork();
        logger.info("Мы кончили");
    }

}
